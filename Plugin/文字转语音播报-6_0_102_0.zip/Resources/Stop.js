﻿var Stop = (function (_super) {
    __extends(Stop, _super);
    function Stop() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    Stop.prototype.execute = function () {
        window.speechSynthesis.cancel();
    };

    return Stop;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("Speak.Stop, Speak", Stop);