var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ObjectOperationCommand;
(function (ObjectOperationCommand) {
    var AddItemToArrayObjectCommand = /** @class */ (function (_super) {
        __extends(AddItemToArrayObjectCommand, _super);
        function AddItemToArrayObjectCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        AddItemToArrayObjectCommand.prototype.execute = function () {
            var commandSettings = this.CommandParam;
            if (!commandSettings.ParamName || !commandSettings.AddItem) {
                return;
            }
            var value = this.evaluateFormula(commandSettings.AddItem);
            var returnParam = Forguncy.CommandHelper.getVariableValue(commandSettings.ParamName);
            if (Object.prototype.toString.call(returnParam) === "[object Array]") {
                returnParam.push(value);
            }
            else {
                throw new Error(ObjectOperationCommand.RSHelper.getRS().Error_AddItemToArrayObjectCommand_ReturnParam_NeedsToBeAnArray);
            }
        };
        return AddItemToArrayObjectCommand;
    }(Forguncy.Plugin.CommandBase));
    ObjectOperationCommand.AddItemToArrayObjectCommand = AddItemToArrayObjectCommand;
})(ObjectOperationCommand || (ObjectOperationCommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("ObjectOperationCommand.AddItemToArrayObjectCommand, ObjectOperationCommand", ObjectOperationCommand.AddItemToArrayObjectCommand);
//# sourceMappingURL=AddItemToArrayObjectCommand.js.map