﻿var Speak = (function (_super) {
    __extends(Speak, _super);
    function Speak() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    Speak.prototype.execute = function () {

        var commandSettings = this.CommandParam;
        var rate = commandSettings.Rate;
        var pitch = commandSettings.Pitch;
        var volume = commandSettings.Volume;
        var playt = commandSettings.Play;
        var text = this.evaluateFormula(commandSettings.Text);
        var voice = this.evaluateFormula(commandSettings.Voice);
        let utterThis = new SpeechSynthesisUtterance();

        utterThis.text = text || "请设置朗读文本";
        utterThis.rate = rate;
        utterThis.pitch = pitch;
        utterThis.volume = volume;
        playt && window.speechSynthesis.cancel();
        window.speechSynthesis.speak(utterThis);
    };

    return Speak;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("Speak.Speak, Speak", Speak);