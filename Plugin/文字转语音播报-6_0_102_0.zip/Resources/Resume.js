﻿var Resume = (function (_super) {
    __extends(Resume, _super);
    function Resume() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    Resume.prototype.execute = function () {
        window.speechSynthesis.resume();
    };

    return Resume;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("Speak.Resume, Speak", Resume);