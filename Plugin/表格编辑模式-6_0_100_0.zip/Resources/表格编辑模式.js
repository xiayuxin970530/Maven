﻿var 表格编辑模式 = (function (_super) {
    __extends(表格编辑模式, _super);
    function 表格编辑模式() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    表格编辑模式.prototype.execute = function () {
        // Get setings
        var commandSettings = this.CommandParam;
        var tableName = commandSettings.biaoming;
        var flag = commandSettings.Flag;
        // Add command logic here

        var listivew = Forguncy.Page.getListView(tableName);
        var spread = listivew.getControl();
        var sheet = spread.getActiveSheet();
        $(".deleteButton").css("z-index", 1);
        var option = {
            allowEditObjects: false,
            allowFilter: false
        };
        sheet.options.protectionOptions = option;
        if (flag==1) {
            spread.options.backColor = 'rgba(200,200,200,0.2)';
            $(".deleteButton").find("img").each(function (i) { $(this).css("display", "none") });
            $(".deleteButton").on('click', function () { return false });
            sheet.options.isProtected = true;
        } else {
            sheet.options.isProtected = false;
            spread.options.backColor = null;
            $(".deleteButton").find("img").each(function (i) { $(this).css("display", "block") });
            $(".deleteButton").on('click', function () { return true });
        }
    };

    return 表格编辑模式;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("表格编辑模式.表格编辑模式, 表格编辑模式", 表格编辑模式);