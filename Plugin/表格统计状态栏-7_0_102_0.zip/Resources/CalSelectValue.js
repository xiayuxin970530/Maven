function getSelectVal(listviewName, type) {
    if(type === undefined){
        type = "noCount";
    }
    var p = Forguncy.Page;
    var listview = p.getListView(listviewName);
    var activeSheet = listview.getControl().getActiveSheet();
    var selections = activeSheet.getSelections();
    var selectArray = [];
    $.each(selections, function (i, val) {
        var row = val.row, col = val.col;
        if (val.row === -1) {
            row = 0;
        }
        if (val.col === -1) {
            col = 0;
        }
        var singleValue = activeSheet.getArray(row, col, val.rowCount, val.colCount);
        $.each(singleValue, function (index, value) {
            if (singleValue.length > 1 || value.length > 1 || selections.length > 1) {
                $.each(value, function (x, xval) {
                    if (type === "noCount") {
                        if (!isNaN(parseFloat(xval))) {
                            selectArray.push(parseFloat(xval));
                        }
                    } else {
                        if (xval !== "" && xval !== null) {
                            selectArray.push(xval);
                        }
                    }
                });
            }
        });
    });
    return selectArray;
}

function sumSelectVal(listviewName) {
    var arrSelectVal = getSelectVal(listviewName);
    var sumSelectVal = "";
    if (arrSelectVal.length !== 0) {
        sumSelectVal = arrSelectVal.reduce(function (prev, cur) {
            return prev + cur;
        }, 0);
    }
    return sumSelectVal;
}

function avgSelectVal(listviewName) {
    var arrSelectVal = getSelectVal(listviewName);
    var sumSelectVal = arrSelectVal.reduce(function (prev, cur) {
        return prev + cur;
    }, 0);
    var avgSelectVal = "";
    if (arrSelectVal.length !== 0) {
        avgSelectVal = sumSelectVal / (arrSelectVal.length);
    }
    return exactAvg(avgSelectVal);
}

function countSelectVal(listviewName, type) {
    var arrSelectVal = getSelectVal(listviewName, type);
    var countSelectVal = "";
    if (arrSelectVal.length !== 0) {
        countSelectVal = arrSelectVal.length;
    }
    return countSelectVal;
}

function maxSelectVal(listviewName) {
    var arrSelectVal = getSelectVal(listviewName);
    var maxSelectVal = "";
    if (arrSelectVal.length !== 0) {
        maxSelectVal = Math.max.apply(Math, getSelectVal(listviewName));
    }
    return maxSelectVal;
}

function minSelectVal(listviewName) {
    var arrSelectVal = getSelectVal(listviewName);
    var minSelectVal = "";
    if (arrSelectVal.length !== 0) {
        minSelectVal = Math.min.apply(Math, getSelectVal(listviewName));
    }
    return minSelectVal;
}

function exactAvg(avgSelectVal) {
    var exactAvgVal = avgSelectVal;
    var index = avgSelectVal.toString().indexOf(".");
    if (index > 0) {
        if (avgSelectVal.toString().split(".")[1].length > 8) {
            exactAvgVal = avgSelectVal.toFixed(8);
        }
    }
    return exactAvgVal;
}