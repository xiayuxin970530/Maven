﻿var Pause = (function (_super) {
    __extends(Pause, _super);
    function Pause() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    Pause.prototype.execute = function () {
        window.speechSynthesis.pause();
    };

    return Pause;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("Speak.Pause, Speak", Pause);