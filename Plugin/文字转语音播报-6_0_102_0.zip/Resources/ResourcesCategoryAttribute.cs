﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Speak
{
    public class ResourcesCategoryAttribute : CategoryAttribute
    {
        public ResourcesCategoryAttribute()
            : base("超哥小工具")
        {
        }
    }
}
