﻿var GETPOST = (function (_super) {
    __extends(GETPOST, _super);
    function GETPOST() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    GETPOST.prototype.execute = function () {
        // Get settings
        var commandSettings = this.CommandParam;
        var normalProperty = commandSettings.NormalProperty;
        var formulaProperty = commandSettings.FormulaProperty;
        var formulaValue = this.evaluateFormula(formulaProperty);

        // Add command logic here
        alert("execute command: " + normalProperty + " " + formulaValue);
    };

    return GETPOST;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("GETPOST.GETPOST, GETPOST", GETPOST);