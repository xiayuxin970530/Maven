﻿var 表格统计状态栏 = (function (_super) {
    __extends(表格统计状态栏, _super);
    function 表格统计状态栏() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    //自定义的属性
    表格统计状态栏.prototype.StatusBarValue = null;
    表格统计状态栏.prototype.StatusBarContainer = null;

    表格统计状态栏.prototype.createContent = function () {
        var self = this;
        var element = this.CellElement;
        var innerContainer = $("<input readonly></input>");
        self.StatusBarContainer = innerContainer;
        innerContainer.css("width", '100%');
        innerContainer.css("height", '100%');
        innerContainer.css("box-sizing", "border-box");
        innerContainer.css("border", "0px");
        innerContainer.css("outline", "none");
        var hAlign = this.getHorizontalAlignment(element.StyleInfo);
        if (hAlign) {
            innerContainer.css("text-align", hAlign);
        }
        return innerContainer;
    };

    //自定义的方法
    表格统计状态栏.prototype.getHorizontalAlignment = function (styleInfo) {
        if (styleInfo) {
            if (styleInfo.HorizontalAlignment === Forguncy.CellHorizontalAlignment.Left) {
                return "left";
            } else if (styleInfo.HorizontalAlignment === Forguncy.CellHorizontalAlignment.Center) {
                return "center";
            } else if (styleInfo.HorizontalAlignment === Forguncy.CellHorizontalAlignment.Right) {
                return "right";
            }
        }
        return null;
    };
    表格统计状态栏.prototype.setFontStyle = function (styleInfo) {
        this.StatusBarContainer.css('font-size', styleInfo.FontSize);
        this.StatusBarContainer.css('font-family', styleInfo.FontFamily);
        this.StatusBarContainer.css('font-style', styleInfo.FontStyle);
        this.StatusBarContainer.css('font-weight', styleInfo.FontWeight);
        this.StatusBarContainer.css('text-decoration', styleInfo.Strikethrough);
        this.StatusBarContainer.css('text-decoration', styleInfo.Underline);
        this.StatusBarContainer.css('color', Forguncy.ColorHelper.Convert(styleInfo.Foreground));
    };
    表格统计状态栏.prototype.setBackColor = function (value) {
        this.StatusBarContainer.css('background-color', Forguncy.ColorHelper.Convert(value));
    };

    表格统计状态栏.prototype.getValueFromElement = function () {
        return this.StatusBarValue;
    };

    表格统计状态栏.prototype.setValueToElement = function (element, value) {
        value = this.StatusBarValue;
    };

    表格统计状态栏.prototype.onLoad = function () {
        var cellTypeMetaData = this.CellElement.CellType;
        var listviewName = cellTypeMetaData.ListViewName;
        if (typeof (listviewName) !== "undefined") {
            var listview = Forguncy.Page.getListView(listviewName);
            var activeSheet = listview.getControl().getActiveSheet();
            var SelectionChanged = GC.Spread.Sheets.Events.SelectionChanged;
            //activeSheet.unbind(SelectionChanged);
            var self = this;
            activeSheet.bind(SelectionChanged, function (e, info) {
                var sumVal = sumSelectVal(listviewName);
                var avgVal = avgSelectVal(listviewName);
                var countVal = countSelectVal(listviewName,"Count");
                var maxVal = maxSelectVal(listviewName);
                var minVal = minSelectVal(listviewName);
                if (cellTypeMetaData.Sum) {
                    if (sumVal !== "") {
                        if (self.StatusBarValue) {
                            self.StatusBarValue = self.StatusBarValue + "求和:" + sumVal + "    ";
                        } else {
                            self.StatusBarValue = "求和:" + sumVal + "    ";
                        }
                    }
                }
                if (cellTypeMetaData.Count) {
                    if (countVal !== "") {
                        if (self.StatusBarValue) {
                            self.StatusBarValue = self.StatusBarValue + "计数:" + countVal + "    ";
                        } else {
                            self.StatusBarValue = "计数:" + countVal + "    ";
                        }
                    }
                }
                if (cellTypeMetaData.Average) {
                    if (avgVal !== "") {
                        if (self.StatusBarValue) {
                            self.StatusBarValue = self.StatusBarValue + "平均值:" + avgVal + "    ";
                        } else {
                            self.StatusBarValue = "平均值:" + avgVal + "    ";
                        }
                    }
                }
                if (cellTypeMetaData.Max) {
                    if (maxVal !== "") {
                        if (self.StatusBarValue) {
                            self.StatusBarValue = self.StatusBarValue + "最大值:" + maxVal + "    ";
                        } else {
                            self.StatusBarValue = "最大值:" + maxVal + "    ";
                        }
                    }
                }
                if (cellTypeMetaData.Min) {
                    if (minVal !== "") {
                        if (self.StatusBarValue) {
                            self.StatusBarValue = self.StatusBarValue + "最小值:" + minVal + "    ";
                        } else {
                            self.StatusBarValue = "最小值:" + minVal + "    ";
                        }
                    }
                }
                self.StatusBarContainer.val("");
                self.StatusBarContainer.val(self.StatusBarValue);
                self.StatusBarValue = "";
            });
        }
    };

    表格统计状态栏.prototype.disable = function () {
        _super.prototype.disable.call(this);
    };

    表格统计状态栏.prototype.enable = function () {
        _super.prototype.enable.call(this);
    };


    return 表格统计状态栏;
}(Forguncy.CellTypeBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CellTypeHelper.registerCellType("表格统计状态栏.表格统计状态栏, 表格统计状态栏", 表格统计状态栏);